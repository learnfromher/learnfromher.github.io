public class Runner {

	public static void main(String[] args) {
		LinkedList example = new LinkedList();
		
		example.addEnd(1);
		System.out.println(example);
		
		example.addEnd(2);
		System.out.println(example);
		
		example.addFront(3);
		System.out.println(example);
		
		example.addMiddle(1, 4);
		System.out.println(example);
		
		example.remove(1);
		System.out.println(example);
		
		example.removeEnd();
		System.out.println(example);
		
		example.removeFront();
		System.out.println(example);
	}

}
