
public class LinkedList {

	private static class Node {
		public int value;
		public Node next;
		public Node prev;
		
		public Node(int value) {
			this.value = value;
			this.next = null;
			this.prev = null;
		}
	}
	
	Node head;
	Node tail;
	int size;
	
	public LinkedList() {
		head = null;
		tail = null;
		size = 0;
	}
	
	public void addEnd(int value) {
		Node toAdd = new Node(value);
		
		if (isEmpty()) {
			head = tail = toAdd;
		}
		
		else {
			tail.next = toAdd;
			toAdd.prev = tail;
			
			tail = toAdd;
		}
		
		++size;
	}
	
	public void addFront(int value) {
		Node toAdd = new Node(value);
		
		if (isEmpty()) {
			head = tail = toAdd;
		}
		
		else {
			head.prev = toAdd;
			toAdd.next = head;
			head = toAdd;
		}
		
		++size;
	}
	
	public void addMiddle(int index, int value) {
		Node toAdd = new Node(value);
		
		if (index > size) {
			throw new IllegalArgumentException();
		}
		
		Node temp = head;
		for(int i = 0; i < index; ++i) {
			temp = temp.next;
		}
		
		Node before = temp;
		Node after = temp.next;
		
		before.next = toAdd;
		if (after != null)
			after.prev = toAdd;
		
		toAdd.prev = before;
		toAdd.next = after;
		
		if(index == size) {
			tail = toAdd;
		}
		
		++size;
	}
	
	public void remove(int index) {
		if (index >= size) {
			throw new IllegalArgumentException();
		}
		
		Node temp = head;
		for(int i = 0; i < index && i < size; ++i) {
			temp = temp.next;
		}
		
		Node before = temp.prev;
		Node after = temp.next;
		
		if(before != null) {
			before.next = after;
		}
		
		if(after != null) {
			after.prev = before;
		}
		
		temp.next = null;
		temp.prev = null;
		
		if(index == 0) {
			head = after;
		}
		
		if(index == size - 1) {
			tail = before;
		}
		
		--size;
	}
	
	public void removeEnd() {
		if (isEmpty()) {
			throw new IllegalArgumentException();
		}
		else if(size == 1) {
			head = tail = null;
		}
		else {
			Node newTail = tail.prev;
			newTail.next = null;
			tail = newTail;	
		}
		
		--size;
	}
	
	public void removeFront() {
		if (isEmpty()) {
			throw new IllegalArgumentException();
		}
		else if(size == 1) {
			head = tail = null;
		}
		else {
			Node newHead = head.next;
			newHead.prev = null;
			head = newHead;	
		}
		
		--size;
	}
	
	public boolean isEmpty() {
		return size == 0;
	}
	
	public String toString() {
		String s = "";
		
		if(size > 0)
			s = "" + head.value;
		
		Node cur = head.next;
		for(int i = 1; i < size; ++i) {
			s += " -> " + cur.value;
			cur = cur.next;
		}
		
		return s;
	}
}
